#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 100
#define NAMESIZE 40
struct Person {
    int score;
    char name[NAMESIZE];
    char surname[NAMESIZE];
};

int main()
{
    int f;
    char read[SIZE+1][SIZE+1];
    struct Person person[SIZE+1];
    struct Person person2[SIZE+1];
    
    int i;
    int read_ctr = 0;
    
    //reading into 2d array from sdtin
    for(i = 0;fgets(read[i],SIZE,stdin);i++)
    {  
        if(read[i][0]=='\n')
        { 
        read_ctr = i;
        break; 
        }
    }
    int ctr = 0;
    sscanf(read[ctr], "%d\n", &f);
if(f <= 0){
    printf("Nespravny vstup\n");
        return 0;
    }
     ctr = 1;
    while (sscanf(read[ctr], "%[^\n]", person[ctr-1].name) == 1){
        ctr++;
    }
    ctr--;
if(ctr <= 0){
        printf("Ziadne prihlasky\n");
        return 0;
    }
 int s_ctr = 0;
    int checker = 0;
for(int a=0; a<=ctr; a++){
        checker = 0;
        for(int b=0; b<=s_ctr; b++){
            if (strcmp(person[a].name, person2[b].name) == 0){
                checker = 1;
                break;
            }
        }
        if (checker == 1){
            continue;
        }
        strcpy(person2[s_ctr].name, person[a].name);
        s_ctr++;
    }
    s_ctr--;
    s_ctr--;
    struct Person buffer;
    for(int a=0; a<=s_ctr; a++){
          for(int b=0; b<=s_ctr-a; b++){
              if (strcmp(person2[b+1].name, person2[b].name) < 0){
                  buffer = person2[b+1];
                  person2[b+1] = person2[b];
                  person2[b] = buffer;
              }
          }
      }
       for(int a = 0;a < s_ctr+2;a++){
        if(a == 0){
            printf("Prijati studenti:\n");
            printf("%s\n",person2[a].name);
        }
        else if(a == f){
            printf("Neprijati studenti:\n");
            printf("%s\n",person2[a].name);
        }
        else{
            printf("%s\n",person2[a].name);
        }
    }

    return 0;
}
