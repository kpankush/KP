#include "snake.h"
#include <stdlib.h>
////////
struct snake* add_snake(struct snake* snake,int x,int y){

    struct snake* head = calloc(1,sizeof(struct snake));

    head->x = x;
    head->y = y;

head->next = snake;

    return head;

}

///////
struct snake* remove_snake(struct snake* snake){
    struct snake* this = snake;
if (this == NULL) return NULL;

//   return NULL;
}

////////
void free_snake(struct snake* sn){
}

int is_snake(struct snake* snake,int x,int y){
    return 0;
}

int step_state(struct state* st){
	int nx = (st->snake->x + st->sx);
    int ny = (st->snake->y + st->sy);
    return END_CONTINUE;
}
