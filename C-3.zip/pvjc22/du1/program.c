#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>

void finish(int c);



int main() {
    
int c;

int score = 0;
char b;    
    
   while(1) {
        c = getchar();
        b = c;
       if(c == EOF){
           
        break;
       }
        if(c>= 'a'&&c<='z'){
         b = toupper(b);
    }
     if (c =='\n'){
              score++;
            }
    
     else if (c>= 'A'&&c <= 'Z'){
               b = tolower(b);
    }
        
    
           

            
            
              finish(b);
        }
        
printf("\nPočet riadkov: %d\n", score);
    
}
void finish(int c) { printf("%c", c);
    }
