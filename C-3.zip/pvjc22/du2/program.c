#include <stdio.h>
#include <stdlib.h>




int main(){
    
  int fifty[50];
  int i=0;  
  int vel=0;
  int score = 0;
  int qwer; 
  while(qwer = scanf("%d",&fifty[i])>0 && qwer != EOF){
    //scanf("%d",&fifty[i]);  
    if(fifty[i]<1){
      break;
    } 
    
    
    if(i < 50){
    
    i++;
    }
 
    
  }
  if (i == 0) {
        printf("Chyba: Málo platných hodnôt.\n");

        return 0;
    }
    
    
  
  for(int q=0;q<i;q++){
    printf("Súťažiaci č. %d vypil %d pohárov.\n",q+1,fifty[q]);
    
    if(fifty[q]>vel){
      vel=fifty[q];             
    }
  }
  
  
  for(int q=0;q<i;q++){
    if(fifty[q]==vel){     
      printf("Výherca je súťažiaci %d ktorý vypil %d pohárov.\n",q+1,vel);
      }
  }
  return 0;
}

