#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100
#define NAMESIZE 40

struct Person {
    int score;
    char name[NAMESIZE];
    char surname[NAMESIZE];
};

int main()
{
    char read[SIZE+1][SIZE+1];
    struct Person person[SIZE+1];
    struct Person person2[SIZE+1];
    
    int i;
    int read_ctr = 0;
    
    //reading into 2d array from sdtin
    for(i = 0;fgets(read[i],SIZE,stdin);i++)
    {  
        if(read[i][0]=='\n')
        { 
        read_ctr = i;
        break; 
        }
    }
    
    //populating structs with data
    int ctr = 0;
    while (sscanf(read[ctr], "%d %s %s", &person[ctr].score, person[ctr].name, person[ctr].surname) == 3){
        ctr++;
    }
    ctr--;
	if (ctr == -1){
        printf("Nepodarilo nacitat nic\n");
    	return 0;
}    
  
    int s_ctr = 0;
    int checker = 0;
    //adding scores
    for(int a=0; a<=ctr; a++){
        checker = 0;
        for(int b=0; b<=s_ctr; b++){
            if (strcmp(person[a].name, person2[b].name) == 0 && strcmp(person[a].surname, person2[b].surname) == 0){
                person2[b].score = person2[b].score + person[a].score;
                checker = 1;
                break;
            }
        }
        if (checker == 1){
            continue;
        }
        strcpy(person2[s_ctr].name, person[a].name);
        strcpy(person2[s_ctr].surname, person[a].surname);
        person2[s_ctr].score = person[a].score;
        s_ctr++;
    }
    s_ctr--;
    
     //temporary buffer for swaps
     struct Person buffer;
     //sorting by the score
     for(int a=0; a<=s_ctr; a++){
          for(int b=0; b<=s_ctr-a; b++){
              if (person2[b+1].score > person2[b].score){
                  buffer = person2[b+1];
                  person2[b+1] = person2[b];
                  person2[b] = buffer;
              }
          }
      }
      
     //sorting by the first name when score is equal
     for(int a=0; a<=s_ctr; a++){
          for(int b=0; b<=s_ctr-a; b++){
              if (strcmp(person2[b+1].name, person2[b].name) <0 && person2[b+1].score == person2[b].score){
                  buffer = person2[b+1];
                  person2[b+1] = person2[b];
                  person2[b] = buffer;
              }
          }
      }
      
      //sorting by the surname when scores and first names are eaual
       for(int a=0; a<=s_ctr; a++){
          for(int b=0; b<=s_ctr-a; b++){
              if (strcmp(person2[b+1].surname, person2[b].surname) <0 && person2[b+1].score == person2[b].score && strcmp(person2[b+1].name, person2[b].name) == 0){
                  buffer = person2[b+1];
                  person2[b+1] = person2[b];
                  person2[b] = buffer;
              }
          }
      }
     
    //stdout
    printf("Vysledky:\n");
    for(int a=0; a<=s_ctr; a++){
        printf("%d %s %s\n", person2[a].score, person2[a].name, person2[a].surname);
    }
    
    return 0;
}  
