#include <stdio.h>
#include<string.h>  
#include<stdlib.h>

void foo(float otazka, float check){
    check = round(check*100)/100;
  
   if(check == otazka){
                  printf("OK\n");
          }else{
                  printf("ZLE\n");
          }
}
int main(){

char sto[100][100];

for(int i = 0;fgets(sto[i],100,stdin);i++){
  if(sto[i][0]=='\n'){
  break;
}
float numerj, numerd, otazka;
        char symbol;
        char symbol_1;
        float check;
        if (sscanf(sto[i], "%f %c %f %c %f", &numerj, &symbol, &numerd, &symbol_1, &otazka) != 5){
            printf("CHYBA\n");
            continue;
        }
        if(symbol_1 != '=' ||symbol != '/' && symbol != '*' && symbol != '-' && symbol != '+' ){
            printf("CHYBA\n");
            continue;
        }
switch (symbol){
              case '*':
     check = numerj * numerd;

           break;
case '+':
     check = numerj + numerd;

     break;
        case '-':
     check = numerj - numerd;

           break;

        case '/':
check = numerj / numerd;

           break;
}
foo(otazka, check);
}
return 0;
}
