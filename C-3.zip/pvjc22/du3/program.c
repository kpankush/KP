#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#define VSTUP 100
         
int main() {
         

char vst[VSTUP];
memset(vst, 0,VSTUP); 
//char* r = fgets(vst,VSTUP,stdin);
 for(int i = 0; i < VSTUP; i++)
    {
        vst [i] = getchar();
        if (vst [i] == NULL) 
        {
            printf("Nacitanie sa nepodarilo");
            return 0;
        }
        //char vst[VSTUP];
// Inicializujeme pamäť
memset(vst, 0,VSTUP);
// Načítame pamäť
char* r = fgets(vst,VSTUP,stdin);
// V prípade že sa načítanie nepodarilo, ukončíme program.
assert(r!=NULL);
int r2 = atol(vst);
if (r2 == 0){
printf("Konverzia sa nepodarila alebo v reťazci sa nachádza nula.");
return 1;
}

if (r){
printf("Nacitanie sa podarilo");
return 0;
}
}
}
