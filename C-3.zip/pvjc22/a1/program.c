#include <stdio.h>
int main(){
    int den; 
    int tyzden = 7;
    int mes;
    int rok;
char sto[100][100];
for(int i = 0;fgets(sto[i],100,stdin);i++){ 
        if(sto[i][0]=='\n'){ 
  break; 
}

if(sscanf(sto[i], "%d.%d.%d", &den, &mes, &rok) != 3||den < 1  ||den > 31 || mes < 1 || mes > 12 ||  rok < 1900 || rok > 2100
||rok % 4 != 0 && mes == 2 && den > 28){
puts("Neplatny datum.");
        continue;
    }
den += tyzden;
 if(rok % 4 != 0 && mes == 2 && den > 28){
        mes +=1;
        den = den- 28;
    }
    else if(mes == 2 && den > 29){
        mes+=1;
        den = den- 29;
    }
if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
if(den > 30){
        mes+=1;
        den = den- 30;
}
}
else if(mes == 1 ||  mes == 3 ||  mes == 5 || mes == 7 ||  mes == 8 ||  mes == 10 ||  mes == 12){
if(den > 31){
        mes+=1;
        den = den - 31;
    }
    }
 if(mes > 12){
        mes = 1;
        rok +=1;
    }
    
printf("%d.%d.%d\n\n", den, mes,  rok);
}
}
