#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "playfair.h"
#include "bmp.h"

int main(){
    char* word_reverse = reverse("rev");
    printf("%s\n", word_reverse);
    free(word_reverse);
    char *encrypted,*decrypted;
// basic test with long text
    encrypted = vigenere_encrypt("CoMPuTeR", "Hello world!");
    printf("%s\n", encrypted);
// "JSXAI PSINR!"

// basic test with long text
    decrypted = vigenere_decrypt("CoMPuTeR", encrypted);
    printf("%s\n", decrypted);
// "HELLO WORLD!"
    free(encrypted);
    free(decrypted);

char *bit_decrypted;
unsigned char* bit_encrypted;

// basic test with long text
bit_encrypted = bit_encrypt("Hello world!");
for(int i=0; i < 12;i++) {
    printf("%x ", bit_encrypted[i]);
    //80 9c 95 95 96 11 bc 96 b9 95 9d 10
}
printf("\n");
bit_decrypted = bit_decrypt(bit_encrypted);
for(int i = 0; i<12;i++){
    printf("%c", bit_decrypted[i]);
}
printf("\n");
free(bit_decrypted);
free(bit_encrypted);
unsigned char *encrypted_bmp;
encrypted_bmp = bmp_encrypt("comp", "Hello world");
for(int i=0; i < 11;i++) {
    printf("%x ", encrypted_bmp[i]);
}
printf("\n");
char *decrypted_bmp;
decrypted_bmp = bmp_decrypt("comp", encrypted_bmp);
for(int i=0; i < 11;i++) {
    printf("%c", decrypted_bmp[i]);
    //Hello world
}
printf("\n");
free(encrypted_bmp);
free(decrypted_bmp);
    return 0;
}

