#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "bmp.h"

char *reverse(const char* text){
    if(text == NULL) return NULL;
    int l = strlen(text);
    char* result = (char*)calloc(l+1, sizeof(char)); 
    for (int i = 0; i < l; i++){
        result[l-i-1] = toupper(text[i]);
    }
    result[l] = '\0';
    return result;    
}

char* vigenere_encrypt(const char* key, const char* text){
    if((text == NULL) || (key == NULL)) return NULL;
    for(int i = 0; key[i]!='\0'; i++){
        if(key[i] < 'A' || key[i] > 'z'){
            return NULL;
        }
    }
    char *up_text = (char*)calloc(strlen(text)+1,sizeof(char));
    strcpy(up_text,text);
    char *up_key = (char*)calloc(strlen(key)+1,sizeof(char));
    strcpy(up_key,key);
    char *result = (char*)calloc(strlen(text)+1,sizeof(char));
    char alp[] = "abcdefghijklmnopqrstuvwxyz";
    int q = 0, x = 0,step = 0,index = 0 , num;
    if(strlen(text) == strlen(up_text)){
       step = 1;
    }
    if(step == 1){
        index = 0;
    }
    if(index == 0){
    while(index < strlen(up_text)){
        for(int j = x; j<strlen(up_key)+1; j++){
            up_text[index] = tolower(up_text[index]);
            up_key[j] = tolower(up_key[j]); 
            if(x == strlen(up_key)){
                j = 0;
                x = 0;
            }
            if(isalpha(up_text[index]) == 0){
                result[q] = up_text[index];
                q++;
                break;
            }else if(up_text[index] >= alp[0] && up_text[index] <= alp[strlen(alp)-1]){
                num = up_text[index] + up_key[j] - (alp[0]*2);
                if(num > strlen(alp)-1){
                    num = num - strlen(alp);
                }
                x++;
                result[q] = alp[num];
                result[q] = toupper(result[q]);
                q++;
                break;
            }
        }
        index++;
    }
}
    free(up_text);
    free(up_key);
    result[q] = '\0';
    return result;
}

char* vigenere_decrypt(const char* key, const char* text){
        if((text == NULL) || (key == NULL)) return NULL;
    for(int i = 0; key[i]!='\0'; i++){
        if(key[i] < 'A' || key[i] > 'z'){
            return NULL;
        }
    }
    char *up_text = (char*)calloc(strlen(text)+1,sizeof(char));
    strcpy(up_text,text);
    char *up_key = (char*)calloc(strlen(key)+1,sizeof(char));
    strcpy(up_key,key);
    char *result = (char*)calloc(strlen(text)+1,sizeof(char));
    char alp[] = "abcdefghijklmnopqrstuvwxyz";
    int q = 0, x = 0,step = 0, index = 1,num = 0;
    if(strlen(text) == strlen(up_text)){
       step = 1;
    }
    if(step == 1){
        index = 0;
    }
    if(index == 0){
     while(index < strlen(up_text)){
        for(int j = x; j<strlen(up_key)+1; j++){
            up_text[index] = tolower(up_text[index]);
            up_key[j] = tolower(up_key[j]); 
            if(x == strlen(up_key)){
                j = 0;
                x = 0;
            }
            if(isalpha(up_text[index]) == 0){
                result[q] = up_text[index];
                q++;
                break;
            }else if(up_text[index] >= alp[0] && up_text[index] <= alp[strlen(alp)-1]){
                num = up_text[index] - up_key[j];
                if(num < 0){
                    num = num + strlen(alp);
                }
                x++;
                result[q] = alp[num];
                result[q] = toupper(result[q]);
                q++;
                break;
            }
        }
        index++;
    }
}
    free(up_text);
    free(up_key);
    result[q] = '\0';
    return result;
}


unsigned char* bit_encrypt(const char* text){
    if(text==NULL) return NULL;
    unsigned char* result = (unsigned char*)calloc(strlen(text)+1,sizeof(char));
	int save = 0, result_num = 0, step = 0,n = 0;
    for(int index = 0; text[index] != '\0'; index++){
        result_num = 0;
		int num=text[index];
		int i=7;
        int binary[8]={0};
	while(num > 0){
		save=num%2;
		binary[i]=save;
		num=num/2;
		i--;
    }
    if(num == 0){
        int j = 0;
        int buf_for_swap = binary[j];
        j++;
        binary[j-1] = binary[j];
        binary[j] = buf_for_swap;
        j++;
        buf_for_swap = binary[j];
        binary[j] = binary[j+1];
        binary[j+1] = buf_for_swap;
        step = 4;
    }   
    if(step == 4){
        if(binary[step] == binary[0]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    if(step == 5){
        if(binary[step] == binary[1]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    }
    if(step == 6){
        if(binary[step] == binary[2]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    }
    if(step == 7){
        if(binary[step] == binary[3]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
        step = 0;
    }
    }
        while(step < 8){
            result_num += binary[step] * pow(2,7-step);
            step++;
        }
        result[n] = result_num;
        n++;
    }
    return result;
}
char* bit_decrypt(const unsigned char* text){
   if(text==NULL) return NULL;
    char* result = (char*)calloc(strlen((char*)(text))+1,sizeof(char));
	int save = 0, result_num = 0, step = 0,n = 0;
    for(int index = 0; text[index] != '\0'; index++){
        result_num = 0;
		int num=text[index];
		int i=7;
        int binary[8]={0};
        step = 4;
	while(num != 0){
		save=num%2;
		binary[i]=save;
		num=num/2;
		i--;
    }
    if(step == 4){
        if(binary[step] == binary[0]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    if(step == 5){    
        if(binary[step] == binary[1]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    }
    if(step == 6){    
        if(binary[step] == binary[2]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    }
    if(step == 7){    
        if(binary[step] == binary[3]){
            binary[step] = 0;
            step++;
        }else{
            binary[step] = 1;
            step++;
        }
    }
    }
    if(num == 0 && step == 8){
        int j = 0;
        int buf_for_swap = binary[j];
        j++;
        binary[j-1] = binary[j];
        binary[j] = buf_for_swap;
        j++;
        buf_for_swap = binary[j];
        binary[j] = binary[j+1];
        binary[j+1] = buf_for_swap;
        step = 0;
    }
       while(step < 8){
            result_num += binary[step] * pow(2,7-step);
            step++;
        }
        result[n] = result_num;
        n++;
    }
    return result;
}

unsigned char* bmp_encrypt(const char* key, const char* text){
	if(key==NULL || text==NULL) return NULL;
    int i = 0;
    while(strlen(key) != i){
	    if(key[i] < 'A' || key[i] > 'z' ){
	    	return NULL;
        }
        i++;
    }
	char *reversed = reverse(text);
	char *encrypt_vigenere = vigenere_encrypt(key, reversed);
	unsigned char *bmp_encrypt = bit_encrypt(encrypt_vigenere);
	free(reversed);
	free(encrypt_vigenere);
	return bmp_encrypt;
}

char* bmp_decrypt(const char* key, const unsigned char* text){
    if(key==NULL || text==NULL) return NULL;
    int i = 0;
    while(strlen(key) != i){
    	if(key[i] < 'A' || key[i] > 'z' ){
    		return NULL;
        }
        i++;
    } 
    char *bmp_decrypt = bit_decrypt(text);
    char *decrypt_vigenere = vigenere_decrypt(key,bmp_decrypt);
    char *reversed = reverse(decrypt_vigenere);
    free(decrypt_vigenere);
    free(bmp_decrypt);
    return reversed;
}
