#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define inter int
#define toch const
#define vrat return

inter main(){

  toch inter max = 1000000;
    char* con = (char*) calloc(max, sizeof(char));
      scanf("%s", con);

        inter string;

          do {
              inter word = 0;
                  string = strlen(con);
                      for (inter x = 0; x < string; x++){
                            word += con[x] - '0';
                                }
                                    sprintf(con, "%d", word);
                                      } while(string != 1);

                                        printf("%s\n", con);
                                          vrat 0;
                                          free(con);
                                          }
