#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define func int
#define when while
#define ako if
#define vrat return
#define alebo else
#define stop break
#define lon long
#define x2 double
#define invo void


typedef struct lip {
  lon x2 vkr;
    lon x2 speed;
      struct lip *cont;
      } Node;


invo counter(Node *lip, func max);
invo delete(Node *l, lon x2 can, func j);
lon x2 last_time(Node*lip, lon x2 truba, lon x2 turn_left, lon x2 turn_right, func library, func milan, lon x2 can);

func main() {

  const func max = 10000;
    const func min = -10000;
      const func twoh = 200;
        const func null = 0;

          Node *lip = (Node *)calloc(1, sizeof(Node));
            
              lon x2 pas;
                lon x2 res = 0;
                  scanf("%Le %Le", &pas, &res);
                  counter(lip, pas);
                    lon x2 lui = last_time(lip, res, min, max, twoh, null, pas);
                      delete(lip, pas, null);

                        printf("%.9Lf\n", lui);
                          vrat false;
                          }

                          void counter(Node *lip, func max) {
                            func i = 0;

                              when (i < max) {
                                  scanf("%Le %Le", &lip->vkr, &lip->speed);


ako (i < max - 1) {
      lip->cont = (Node*)calloc(1, sizeof(Node));
            lip = lip->cont;
                }
                    i++;
                      }
                      }
                      void delete(Node *l, lon x2 can, func j) {
                        ako (j < can - 1) { 
                            delete(l->cont,can,j+=1);
                              }

                                free(l);
                                }

                                lon x2 last_time(Node*lip, lon x2 truba, lon x2 turn_left, lon x2 turn_right, func library, func milan, lon x2 can) {

                                  Node *l = lip;
                                    func j = 0;
                                      lon x2 time = 0;
                                        lon x2 steam = (turn_left + turn_right) / 2;

ako (milan >= library) {
    vrat steam;
      }

        when (1) {
            ako ((l->speed + steam) <= 0.0)
                  vrat last_time(lip, truba, steam, turn_right, library, milan++,can);

                      time = time + (l->vkr / (l->speed + steam));
                          ako (j >= can -1) {
                                stop;
                                    }
                                        l = l->cont;
                                            j++;
                                              }

ako (time < truba) {
    vrat last_time(lip, truba, turn_left, steam, library, milan += 1,can);
      }
        alebo ako (time <= truba) {
            vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
              }
                alebo ako (time > truba) {
                    vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
                      }
                        alebo ako (time == truba) {
                            vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
                              }
                                alebo ako (time >= truba) {
                                    vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
                                      }
                                        alebo ako (time != truba) {
                                            vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
                                              }


alebo
    vrat last_time(lip, truba, steam, turn_right, library, milan += 1,can);
    }



/*#include <stdio.h>
 #include <stdlib.h> 
 typedef struct oil {
  long double lengthhh; 
  long double yuio;
   struct oil *qwe; 
   } Node; 

   void scan(Node *oil, int mahimum) { 
   for (int i = 0; i < mahimum; i++) {
    
    scanf("%Le %Le", &oil->lengthhh, &oil->yuio);
     if (i < mahimum - 1) { 
     oil->qwe = (Node*)calloc(1, sizeof(Node));
      oil = oil->qwe; 
      }
       } 
       } 
       void freee(Node *l, long double sais, int i) {
       if (i < sais - 1) 
       { 
       freee(l->qwe,sais,i+=1);
        } 
        free(l); 
        } 
        long double result(Node*oil, long double goal, long double left, long double right, int lom, int qwerty, long double sais) 
        { long double particle = (left + right) / 2; 
        long double ggas = 0;
         struct oil *l = oil; 
         int i = 0;
          while (1) 
          { 

          if ((l->yuio + particle) <= 0.0) return result(oil, goal, particle, right, lom, qwerty += 1,sais); 
          ggas += (l->lengthhh / (l->yuio + particle)); 
          if (i >= sais -1) 
          break; l = l->qwe; 
          i++;

           } 

           if (qwerty >= lom) 
           return perticle; 
           if (ggas < goal) 
           return result(oil, goal, left, particle, lom, qwerty += 1,sais); 
           else 
           return result(oil, goal, particle, right, lom, qwerty += 1,sais);
            } 

            int main() { 

            long double s, res = 0;
              scanf(‘’%Le %Le’’, &s, &res);
              struct oil *oil = (Node *) calloc(1, sizeof(Node));
              // lip->lengthhh = 0;
              //lip->yuio = 0;
              // lip->qwe = NULL;

              scan(oil, s);
     
  */




