#include <stdio.h>
#include <stdlib.h>
#include "hof.h"
#include "k.h"
#include "ui.h"
#include <curses.h>


#include <ctype.h>

int load(struct player list[]){
bool first = false;
    FILE * fp = fopen("score", "r");
        if (fp == NULL)
            {
                    return -1;
                        }
                             int chr = getc(fp);
                                int count_lines = 0;
                                    while (chr != EOF)
                                        {
                                                //Count whenever new line is encountered
                                                        if (chr == '\n')
                                                                {
                                                                            count_lines = count_lines + 1;
                                                                                        first = true;
                                                                                                }
                                                                                                        //take next character from file.
                                                                                                                chr = getc(fp);
                                                                                                                        if (first){
                                                                                                                                    if(!isalpha(chr)){
                                                                                                                                                    count_lines--;
                                                                                                                                                                    fclose(fp);
                                                                                                                                                                                    return count_lines;
                                                                                                                                                                                                }
                                                                                                                                                                                                            first = false;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                            fclose(fp);
                                                                                                                                                                                                                                return count_lines;
                                                                        

}

bool save(const struct player list[], const int size){
return true;
}

/*bool add_player(struct player list[], int* size, const struct player player){

return true;
}*/
