#include <stdio.h>
#include <stdlib.h>
#include "hof.h"
#include "k.h"
#include "ui.h"
#include <curses.h>



int main(){

struct game game = {
      .board = {
                      {'D', 'B', 'C', 'D'},
                                      {'C', 'F', 'G', 'H'},
                                                      {'I', 'J', ' ', 'A'},
                                                                      {'B', ' ', 'D', ' '}
                                                                                     },
                                                                                                .score = 0
                                                                                                   };
render(game);

struct player list[10];

int num = 7;
//int *ptr = &num;
add_random_tile(&game);
save(list, num);

is_game_won(game);
printf("%d\n", is_move_possible(game));

int numb = load(list);
printf("%d\n", numb);
return 0;
}
