#include <stdlib.h>
#include <stdio.h>
#include "k.h"

void add_random_tile(struct game *game){
    int row, col;
    // find random, but empty tile
    do{
        row = rand() % SIZE;
        col = rand() % SIZE;
    }while(game->board[row][col] != ' ');

    // place to the random position 'A' or 'B' tile
    if(rand() % 2 == 0){
        game->board[row][col] = 'A';
    }else{
        game->board[row][col] = 'B';
    }
}


bool is_game_won(const struct game game){
 int g,h = 0;
    bool state = false;
       for(g=0; g<SIZE; g++){
            for(h=0; h<SIZE; h++){
                    if(game.board[g][h] == 'K'){
                                state = true;
                                        }
                                             }
                                                }
                                                   return state;



}

bool is_move_possible(const struct game game){
int g,h = 0;
     
          for(g=1; g<SIZE-1; g++){
                  for(h=1; h<SIZE-1; h++){
        if(game.board[g][h] == game.board[g][h+1] || game.board[g][h] == game.board[g][h-1] || game.board[g][h] == game.board[g+1][h] ||
                                             game.board[g][h] == game.board[g-1][h] || game.board[g][h] == ' ')
                                                         {
                                                                         return true;
                                                                                     }
 }
         
              }

                for(g=0; g<SIZE; g++){
                            for(h=0; h<SIZE; h++){
                                            if(game.board[g][h] == ' '){
                                                                return true;
                                                                                }
                                                                                         }
                                                                                                 }
  
           for(g=0; g<SIZE; g+=SIZE-1){
                   for(h=1; h<SIZE; h++){
                               if(game.board[g][h] == game.board[g][h-1]){
                                                   return true;
                                                                   }
                                                                               if(game.board[h][g] == game.board[h-1][g]){
                                                                                                   return true;
                                                                                                                   }
                                                                                                                             }
                                                                                                                                     }

                                                                                                      return false;

}

/*bool update(struct game *game, int dy, int dx){
return true;
}*/
