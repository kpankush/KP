#include <superkarel.h>
#define SPEED 50

bool go();
bool work(); 
bool just();
void step_left();
void turn_back();
void turn_right();
void go_back();


int main(){
turn_on("task_3.kw");

set_step_delay(SPEED);

go();
work();


while( not_facing_south()|| right_is_clear()||front_is_clear() ){
just();
}
go_back();


turn_off();
return 0;

}


bool go(){
while(front_is_clear()){
if(beepers_present()){
pick_beeper();
}
step();
}
if(beepers_present()){
pick_beeper();
}
turn_back();

while(front_is_clear()){
if(right_is_blocked()&&beepers_in_bag()) {
if (no_beepers_present( ) ) {
put_beeper();
}
}
step();
}
return true;
}


bool just(){
while(facing_east()&&front_is_clear()){
if(beepers_present()){
pick_beeper();
}
step();
}
if(beepers_present()){
pick_beeper();
}
while(facing_west()&&front_is_clear()){
if(beepers_in_bag()){
turn_right();
step();
if(beepers_present()){
turn_back();
step();
put_beeper();
turn_right();
}

if(no_beepers_present()){
turn_back();
step();
turn_right();
}
}
step();
}
if(facing_east()&&front_is_blocked()){
turn_back();
}
if(facing_west()&&front_is_blocked()){
turn_left();
if(front_is_clear()){
step();
turn_left();
}
}
return true;
}

bool work () {
turn_left();
if (front_is_clear() ) {
step();
turn_left();
}
return true;
}

void go_back() {
    step_left();
    while (no_beepers_present() ) {
    if (facing_north() && front_is_clear() ) {
    step();
    }
    if (front_is_blocked() && facing_north() ) {
    turn_back();
    }
    if (facing_south() && front_is_clear() ) {
    step();
    }
    if (front_is_blocked() && facing_south() ) {
    step_left();
    }
}
while (front_is_clear() ) {
step();
}
turn_left();
while (front_is_clear() ) {
step();
}
turn_back();
}

void step_left() {
turn_left();
step();
turn_left();
}

void turn_back() {
set_step_delay(0);
turn_left();
set_step_delay(SPEED);
turn_left();
}

void turn_right(){
set_step_delay(0);
turn_left();
turn_left();
set_step_delay(SPEED);
turn_left();
}
