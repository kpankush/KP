#include <superkarel.h>
void ert();
void pool();
void turn_right();
void start();
void goback();
void to();

int main(){
 turn_on ("task_1.kw");
 set_step_delay(200);
ert();
 start();
 to();
 goback();
 pool();
 turn_off();
 return 0;
 }

void turn_right(){
turn_left();
turn_left();
turn_left();
}

void to(){
pick_beeper();
}

void ert(){


put_beeper();

if(front_is_clear() == false ){
turn_left();
}
step();




}

 void start(){

    while (no_beepers_present()){
      if (right_is_clear()){
turn_right();
      }
    
else if (left_is_blocked() == false  && front_is_blocked()){
turn_left();
}
else if (front_is_blocked()){
turn_left();
turn_left();
}
step();

}
}

void goback(){
while (no_beepers_present() ){
        if (left_is_clear()){
   turn_left();
          }
    
      else if (left_is_clear()  && front_is_blocked()){
      turn_left();
      turn_left();
      turn_left();
      }
        else if (front_is_blocked()){
         turn_left();
          turn_left();
               }
                step();
                
                  }
                   }



void pool(){
while(not_facing_west()){
turn_left();
}
}

