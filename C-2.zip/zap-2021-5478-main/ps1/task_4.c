#include <superkarel.h>
void start();
int main (){
turn_on("task_4.kw");
set_step_delay(200);
start();
//pick_beeper();
turn_left();

turn_off();
return 0;
}
void turn_right(){
turn_left();
turn_left();
turn_left();
}
void start(){
if(left_is_clear()){
turn_left();
}
while(front_is_clear() ||  left_is_clear() || not_facing_south()){ 
while(front_is_clear() && facing_north()){

  
    if(beepers_present()){
     step();
     
     if(no_beepers_present()){
        put_beeper();
     
     }
     }
     
if(no_beepers_present() && front_is_clear()){
step();
}
 
}

if(front_is_blocked()&& facing_north()){
turn_right();
turn_right();
}
while(facing_south() && front_is_clear()){
if(beepers_present()){
       step();
              if(no_beepers_present()){
                        put_beeper();
                               }
                                    }
        if(front_is_clear() && no_beepers_present()){
              step();
        }

}

if(front_is_blocked() && facing_south() && left_is_clear()  ){
turn_right();
turn_right();
turn_right();
step();
turn_right();
turn_right();
turn_right();
}


}
}
