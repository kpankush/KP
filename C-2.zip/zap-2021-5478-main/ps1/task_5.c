#include <superkarel.h>

void start();

void western();
void turn_right();
int main(){
set_step_delay(150);
turn_on("task_5.kw");

while(not_facing_south() ){
    turn_left();
}
while(front_is_clear() ){
    step();
}
if(left_is_clear() && front_is_blocked() ){
turn_left();
}
while(front_is_clear() ){
    step();
}
turn_left();
start();

western();
turn_left();
western();
turn_left();
turn_left();
turn_off();
return 0;
}

void start(){
while(front_is_clear()&&no_beepers_present()){
put_beeper();
step();
if(front_is_blocked()){
turn_left();
}
if(beepers_present()){
turn_left();
}
}
}



void western(){
if(front_is_clear()){
step();
step();
western();
step();
}


else{
turn_left();
turn_left();
}
}
