#include <superkarel.h>

void start();
void goback();
void bback();
void turn_right();
void fin();
int main(){
turn_on ("task_2.kw");
set_step_delay(200);
start();
bback();
goback();
fin();
turn_off();
return 0;
}


void start(){
while(no_beepers_present()){
if(left_is_clear()){
turn_left();
}
else if (left_is_blocked() == false && front_is_blocked()){
}
else if (front_is_blocked()){
turn_left();
turn_left();
turn_left();
turn_left();
turn_left();
turn_left();

}
step();
}
}

void goback(){
while (front_is_clear()||right_is_clear()||left_is_clear()){
if(front_is_clear()){
step();
}
else if(right_is_clear()){
turn_right();
}
}
}
void bback(){
pick_beeper();
turn_left();
turn_left();
step();
}


void turn_right(){
turn_left();
turn_left();
turn_left();
}

void fin(){
while(not_facing_north()){
turn_right();
}
}
