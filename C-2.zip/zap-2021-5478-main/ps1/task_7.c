#include <superkarel.h>

void start();
void turn_right();
void go();

int main(){

turn_on("task_7.kw");
set_step_delay(100);

start();
while(not_facing_east() || front_is_clear() || right_is_clear() ){
    if(left_is_blocked() && front_is_clear() && beepers_present() ){
            step();
}
    if(left_is_clear() && beepers_present() && front_is_clear() ){
          put_beeper();
                 turn_left();
                         step();
                 
                }

  if(no_beepers_present() ){
          go();
              }
                  if(beepers_present() ){
                          pick_beeper();
   if(beepers_present() ){
            turn_left();
   if(front_is_clear() ){   
step();
   }
    }

    if(no_beepers_present() ){
  turn_left();
  turn_left();
     step();
     put_beeper();
                 turn_left();  
                 turn_left();
step();
  turn_left(); 
  if(front_is_clear() ){ 
  step();        
  }   

 }


  }

  }

  turn_left();
  turn_left();

  while(  front_is_clear() ){
      if(beepers_present() ){
          pick_beeper();
              }
                  step();
                  }

turn_left();
turn_left();

while(front_is_clear() ){
step();
}

turn_left();
turn_left();

while(front_is_clear()  || beepers_present() ){
    if(beepers_present() ){
            while(beepers_present() ){
                        pick_beeper();
                                }
turn_right();
        step();
        put_beeper();
       turn_left();
    turn_left();
         step();
        turn_right();    
               }
   if(no_beepers_present() && front_is_clear() ){
               step();
                   }
       }

       turn_off("task_7.kw");
       return 0;


       }
       void start(){

       while(front_is_clear() && facing_east() ){
        if(no_beepers_present() ){
           put_beeper();
            }
             if(beepers_present() ){
                step();
                 }
                 }
          if(no_beepers_present() ){
          put_beeper();
          }

          while(not_facing_west() ){
          turn_left();
          }
          while(front_is_clear() && facing_west() ){
          step();
          }
          while(not_facing_east() ){
          turn_left();
          }
          }



          void turn_right(){

          turn_left();
          turn_left();
          turn_left();

          }

          void go(){
 
 while(no_beepers_present() || front_is_clear() || not_facing_south() ){
            while (beepers_present() == false ){
              if (right_is_clear() ){
                 turn_right();
 
 }

 else if (left_is_clear() && front_is_clear() == false ){
    turn_left();
      }
        else if (front_is_blocked() ){
           turn_left();
              turn_left();
                }
                  step();
                    }

}
}
