#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
void encode_char(const char character, bool bits[8])
{
    if(character == '!'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
     }
     if(character == ':'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
     }
     if(character == ';'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }

if(character == '"'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
     }
if(character == '#'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }
if(character == '$'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
     }
if(character == '%'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
     }
if(character == '&'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
     }
if(character == '('){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
     }
if(character == ')'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
     }
     if(character == '*'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
     }
     if(character == '+'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }
if(character == ','){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
     }
     if(character == '-'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
     }
     if(character == '/'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
     }
     if(character == '<'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
     }
     if(character == '='){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
     }
if(character == '>'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
     }
if(character == '@'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
     }
if(character == '['){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }
     if(character == ']'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
     }
     if(character == '^'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
     }
if(character == '_'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
     }
if(character == '`'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
     }
if(character == '{'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }
if(character == '|'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
     }
     if(character == '~'){
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
     }

     


    if(character == '0'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }
    if(character == '1'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }
    if(character == '2'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }
     if(character == '3'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
     }
     if(character == '4'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
     }
     if(character == '5'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
     }
     if(character == '6'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
     }
     if(character == '7'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
     }
     if(character == '8'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
     }
     if(character == '9'){
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
     }
    if (character == 'A')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'B')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'C')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'D')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }
    if (character == 'E')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'F')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'G')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'H')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;

        bits[7] = 0;
    }
    if (character == 'I')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'J')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'K')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }
    if (character == 'L')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'M')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }
    if (character == 'N')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'O')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'P')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'Q')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'R')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }
    if (character == 'S')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'T')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'U')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }
    if (character == 'V')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'W')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }
    if (character == 'X')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'Y')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'Z')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 0;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'a')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'b')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }
    if (character == 'c')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'd')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'e')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }
    if (character == 'f')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }
    if (character == 'g')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }
    if (character == 'h')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'i')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'j')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'k')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'l')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }
    if (character == 'm')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'n')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 'o')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }

    if (character == 'p')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }

    if (character == 'q')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }
    if (character == 'r')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }

    if (character == 's')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        ;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 1;
    }
    if (character == 't')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 0;
    }
    if (character == 'u')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'v')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 0;
    }
    if (character == 'w')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 0;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }
    if (character == 'x')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }
    if (character == 'y')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }

    if (character == 'z')
    {
        bits[0] = 0;
        bits[1] = 1;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 0;
        bits[6] = 1;
        bits[7] = 0;
    }
    if (character == ' ')
    {
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 0;
    }
    if (character == '!')
    {
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 0;
        bits[4] = 0;
        bits[5] = 0;
        bits[6] = 0;
        bits[7] = 1;
    }
    if (character == '?')
    {
        bits[0] = 0;
        bits[1] = 0;
        bits[2] = 1;
        bits[3] = 1;
        bits[4] = 1;
        bits[5] = 1;
        bits[6] = 1;
        bits[7] = 1;
    }
        if (character == '.')
        {
            bits[0] = 0;
            bits[1] = 1;
            bits[2] = 1;
            bits[3] = 0;
            bits[4] = 1;
            bits[5] = 1;
            bits[6] = 1;
            bits[7] = 0;
        }
        if (character == ',')
        {
            bits[0] = 0;
            bits[1] = 0;
            bits[2] = 1;
            bits[3] = 0;
            bits[4] = 1;
            bits[5] = 1;
            bits[6] = 0;
            bits[7] = 0;
        }
    }

    char decode_byte(const bool bits[8])
    {

        int x = 0;

if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 34;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 35;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 36;
        }
if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 37;
        }
if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 38;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 39;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 40;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 41;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 42;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 43;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 44;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 45;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 46;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 47;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 58;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 59;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 60;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 61;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 62;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 64;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 91;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 93;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 94;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 96;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 123;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 124;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 125;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 126;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 130;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 132;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 136;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 145;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 146;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 147;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 148;
        }
        if (bits[0] == 1 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 180;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 65;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 66;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 67;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 68;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 69;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 70;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 71;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 72;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 73;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 74;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 75;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 76;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 77;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 78;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 79;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 80;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 81;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 82;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 83;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 84;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 85;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 86;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 87;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 88;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 89;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 0 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 90;
        }

        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 97;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 98;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 99;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 100;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 101;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 102;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 103;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 104;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 105;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 106;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 107;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 108;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 109;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 110;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 111;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 112;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 113;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 114;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 0 && bits[6] == 1 && bits[7] == 1)
        {
            x = 115;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 116;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 0 && bits[7] == 1)
        {
            x = 117;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 118;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 119;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 120;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 121;
        }
        if (bits[0] == 0 && bits[1] == 1 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 0 && bits[6] == 1 && bits[7] == 0)
        {
            x = 122;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 0)
        {
            x = 46;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 1 && bits[5] == 1 && bits[6] == 0 && bits[7] == 0)
        {
            x = 44;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 1)
        {
            x = 33;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 1 && bits[4] == 1 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 63;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 0 && bits[6] == 0 && bits[7] == 0)
        {
            x = 32;
        }
        if (bits[0] == 0 && bits[1] == 0 && bits[2] == 1 && bits[3] == 0 && bits[4] == 0 && bits[5] == 1 && bits[6] == 1 && bits[7] == 1)
        {
            x = 39;
        }

        return x;
    }

    void encode_string(const char string[], bool bytes[strlen(string) + 1][8])
    {
        bytes[strlen(string)][0] = false;
        bytes[strlen(string)][1] = false;
        bytes[strlen(string)][2] = false;
        bytes[strlen(string)][3] = false;
        bytes[strlen(string)][4] = false;
        bytes[strlen(string)][5] = false;
        bytes[strlen(string)][6] = false;
        bytes[strlen(string)][7] = false;
        for (int number_letter = 0; number_letter < strlen(string); number_letter++)
        {
            int character = string[number_letter];
            if (character == 'A')
            {

                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'B')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;

                bytes[number_letter][7] = 0;
            }
            if (character == 'C')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'D')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;

                bytes[number_letter][7] = 0;
            }

            if (character == 'E')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }

            if (character == 'F')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;

                bytes[number_letter][7] = 0;
            }

            if (character == 'G')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }

            if (character == 'H')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'I')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'J')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'K')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'L')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'M')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'N')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'O')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'P')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'Q')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'R')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'S')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'T')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'U')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'V')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'W')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'X')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }

            if (character == 'Y')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'Z')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 0;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'a')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'b')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'c')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'd')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'e')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'f')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;

                bytes[number_letter][7] = 0;
            }
            if (character == 'g')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'i')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'j')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;

                bytes[number_letter][7] = 0;
            }
            if (character == 'k')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'l')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'm')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'n')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'o')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }

            if (character == 'p')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'q')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;

                bytes[number_letter][7] = 1;
            }
            if (character == 'r')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 's')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                ;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 't')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'u')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'v')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == 'w')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == 'x')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == 'y')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == 'z')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
            if (character == ' ')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 0;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 0;
            }
            if (character == '!')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 0;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 0;
                bytes[number_letter][5] = 0;
                bytes[number_letter][6] = 0;
                bytes[number_letter][7] = 1;
            }
            if (character == '?')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 0;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 1;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 1;
            }
            if (character == '.')
            {
                bytes[number_letter][0] = 0;
                bytes[number_letter][1] = 1;
                bytes[number_letter][2] = 1;
                bytes[number_letter][3] = 0;
                bytes[number_letter][4] = 1;
                bytes[number_letter][5] = 1;
                bytes[number_letter][6] = 1;
                bytes[number_letter][7] = 0;
            }
        }
    }
void decode_bytes(const int rows, bool bytes[rows][8], char string[rows]){
   for(int q = 0 ; q < rows; q++){
   int x = 0;
  
   if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
                  {
                             x = 65;
  
                                     }
  if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
          {
                      x = 57;
                              }
 
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                     x = 56;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 55;
                             }
  if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
          {
                      x = 54;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
          {
                      x = 53;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                     x = 52;
                              }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
          {
                      x = 51;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                      x = 50;
                              }
if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
          {
                      x = 49;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                      x = 48;
                              }
 
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
          {
                      x = 66;
                              }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
          {
                      x = 67;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                      x = 68;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
          {
                      x = 69;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                      x = 70;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
          {
                      x = 71;
                             }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                      x = 72;
                             }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
          {
                      x = 73;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
          {
                      x = 74;
                              }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
          {
                      x = 75;
                              }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
          {
                     x = 76;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 77;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 78;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 79;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 80;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 81;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 82;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 83;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 84;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 85;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 86;
                            }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 87;
                             }
if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 88;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 89;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 0 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 90;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 97;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 98;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
        {
                     x = 99;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 100;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 101;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
        {
                     x = 102;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 103;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 104;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 105;
                             }
if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 106;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
        {
                     x = 107;
                            }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 108;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 109;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 110;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 111;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 112;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 113;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 114;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 115;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
        {
                     x = 116;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                    x = 117;
                             }
if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 118;
                             }
  if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
          {
                      x = 119;
                              }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 120;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
        {
                     x = 121;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 1 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 0 && bytes[q][6] == 1 && bytes[q][7] == 0)
         {
                     x = 122;
                             }
if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 0)
        {
                     x = 46;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 0 && bytes[q][7] == 0)
         {
                     x = 44;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 1)
         {
                     x = 33;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 1 && bytes[q][4] == 1 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 63;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 0 && bytes[q][6] == 0 && bytes[q][7] == 0)
        {
                     x = 32;
                             }
 if (bytes[q][0] == 0 && bytes[q][1] == 0 && bytes[q][2] == 1 && bytes[q][3] == 0 && bytes[q][4] == 0 && bytes[q][5] == 1 && bytes[q][6] == 1 && bytes[q][7] == 1)
         {
                     x = 39;
                             }
string[q] = x;
  }
}
void bytes_to_blocks(const int cols, const int offset, bool blocks[offset * 8][cols], const int rows, bool bytes[rows][8])
{
    for (int i = 0; i < cols; i++)
    {
        for (int j = 0; j < offset * 8; j++)
        {
            blocks[j][i] = false;
        }
    }
    for (int i = 0; i < cols; i++)
    {
        for (int j = 0; j < offset * 8; j++)
        {
            if (j / 8 * cols + i < rows)
            {
                blocks[(j % (offset * 8)) % (offset * 8)][i % cols] = bytes[j / 8 * cols + i][(j % 8) % 8];
            }
        }
    }
}

    void blocks_to_bytes(const int cols, const int offset, bool blocks[offset * 8][cols], const int rows, bool bytes[rows][8])
    {
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < rows / offset * 8; j++)
            {
                bytes[(j / 8 * cols + i)][(j % 8) % 8] = blocks[(j % (rows / offset * 8)) % (offset * 8)][i % cols];
            }
        }
    }

    int main()
    {

        return 0;
    }
