#include <stdio.h>
#include <math.h>

int main() {

}


///ghj

float lift_a_car(const int stick_length, const int human_weight, const int car_weight){
    
float r1 = human_weight;
float r2 = car_weight;
float m1 = stick_length;
float xery = (float)r1*(float)m1; 
float yrex = (float)r1+(float)r2;
//xery/= (float)r1+(float)r2;
//loat finish = xery;

float f = roundf((xery/yrex)*100)/100;
return f;
    
}



float unit_price(const float pack_price, const int rolls_count, const int pieces_count){
float q;
float squer;
squer = pack_price/rolls_count;
squer /= pieces_count;
squer += 3;
squer -= 3;
squer *= 100;

q = round(squer*100)/100;

return q;  

}


int collatz(const int number){
int t;
int score =1; 
int one = 1;

int qw = number;
t = 3;

if(qw%2 == 1){ 
qw = qw / 2;

}
else{
float v = qw * t;
v +=one;

}

score++;

return score;
}

int opposite_number(const int n, const int number){

int i = n;
if(i % 2 == 0){ 
float w =0;
int t = i/2;
w=t+number;
return w;
}
else{
float e;
int r = i/2; 
e=number-r;
return e;
}

}

void counter(const int input_array[], const int array_size, int result_array[2]) {
int y = 0;
int r = 0;

for(int k=0; k<array_size; k++){
if(k%2==0){
y+=input_array[k];
k++;
}
for(int p=1; p<array_size; p++){
if(p&1){
r+=input_array[p];
p++;
}
}
}
result_array[0]=y;
result_array[1]=r;
}
