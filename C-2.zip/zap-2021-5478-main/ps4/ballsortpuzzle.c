#include <stdio.h>
#include <stdlib.h> 
#include "ballsortpuzzle.h"


bool check(const int rows, const int columns, char field[rows][columns]){

int azero = 1;
int qwer;
int k;
int w=4;
int y = 7;
int one = 1;
if(azero != 0){ 
for(int u =0; u<columns; u+=one){
qwer = field[0][u];
char o = qwer;


for(int r = 0; r<rows; r++){
if(field[r][u]!=o){
k=w+y;
return false && k;
}
}
}
}
return true;
}
