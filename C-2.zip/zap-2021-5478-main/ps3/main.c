#include <stdio.h>
#include <stdlib.h>
#include "hangman.h"
#include <time.h>
int main()
{
    srand(time(NULL));
    char word[30];
    get_word(word);
    hangman(word);
    return 0;
}
