#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include "hangman.h"


int get_word(char secret[]){
    // check if file exists first and is readable
    FILE *fp = fopen(WORDLIST_FILENAME, "rb");
    if( fp == NULL ){
        fprintf(stderr, "No such file or directory: %s\n", WORDLIST_FILENAME);
        return 1;
    }

    // get the filesize first
    struct stat st;
    stat(WORDLIST_FILENAME, &st);
    long int size = st.st_size;

    do{
        // generate random number between 0 and filesize
        long int random = (rand() % size) + 1;
        // seek to the random position of file
        fseek(fp, random, SEEK_SET);
        // get next word in row ;)
        int result = fscanf(fp, "%*s %20s", secret);
        if( result != EOF )
            break;
    }while(1);

    fclose(fp);

    return 0;
}

int is_word_guessed(const char secret[], const char letters_guessed[]){
    char secret_letter = '\0';
    int secret_index = 0;
    while (secret[secret_index] != '\0'){//for every secret letter
        secret_letter = secret[secret_index];
        char guessed_letter = '\0';
        int guessed_index = 0;
        bool is_secret_letter_in_gueesed_letters = false;
        while (letters_guessed[guessed_index] != '\0'){//check evety guessed letter
            guessed_letter = letters_guessed[guessed_index];
            if (secret_letter == guessed_letter){
                is_secret_letter_in_gueesed_letters = true;
            }
            guessed_index++;
        }
        if (is_secret_letter_in_gueesed_letters == false){
            return 0;
        }
        secret_index++;
    }
    return 1;
}

void get_guessed_word(const char secret[], const char letters_guessed[], char guessed_word[]){
    int secret_index = 0;
    char secret_letter = '\0';
    while (secret[secret_index] != '\0'){
        secret_letter = secret[secret_index];
        char guessed_letter = '\0';
        int guessed_index = 0;
        bool is_secret_letter_in_gueesed_letters = false;
        while (is_secret_letter_in_gueesed_letters == false && letters_guessed[guessed_index] != '\0'){
            guessed_letter = letters_guessed[guessed_index];
            if (secret_letter == guessed_letter){
                is_secret_letter_in_gueesed_letters = true;
            }
            guessed_index++;
        }
        if (is_secret_letter_in_gueesed_letters == false){
            guessed_word[secret_index] = '_';
        }
        else {
            guessed_word[secret_index] = guessed_letter;
        }
        secret_index++;
    }
    guessed_word[secret_index] = '\0';
    for (int i = 0; i < strlen(secret) - 1; i++)
        printf("%c ", guessed_word[i]);
    printf("%c\n", guessed_word[strlen(secret)-1]);
}

void get_available_letters(const char letters_guessed[], char available_letters[]){
    int available_letters_counter = 0;
    for (int ascii_index = 97; ascii_index <= 122; ascii_index++){
        char guessed_letter = '\0';
        int guessed_index = 0;
        bool is_ascii_symbol_in_guessed_letters = false;
        while (letters_guessed[guessed_index] != '\0'){
            guessed_letter = letters_guessed[guessed_index];
            if (ascii_index == (int)guessed_letter){
                is_ascii_symbol_in_guessed_letters = true;
            }
            guessed_index++;
        }
        if (is_ascii_symbol_in_guessed_letters == false){
            available_letters[available_letters_counter] = (char)ascii_index;
            available_letters_counter++;
        }
    }
    available_letters[available_letters_counter] = '\0';
    printf("%s\n", available_letters);
}

void hangman(const char secret[]){
    int guesses = 8;
    char guessed_letters[100];
    guessed_letters[0] = '\0';
    char available_letters[100];
    int count_of_normal_guesses = 0;
    printf("Welcome to the game, Hangman!\nI am thinking of a word that is %ld letters long.\n", strlen(secret));
    while (guesses > 0){
        printf("-------------\nYou have %d guesses left.\nAvailable letters: ", guesses);
        get_available_letters(guessed_letters, available_letters);
        printf("Please guess a letter: ");
        char guessed_word[100];
        scanf("%s", guessed_word);
        
        if (strlen(guessed_word) > 1){
            if (is_word_guessed(secret, guessed_word) == 1){
                printf("Congratulations, you won!\n");
                guesses = 0;
            }
            else{
                printf("Sorry, bad guess. The word was %s.\n", secret);
                guesses = -1;
            }
        }
        else {
            char guessed_letter = guessed_word[0];
            guessed_letter = tolower(guessed_letter);
            if (guessed_letter < 97 || guessed_letter > 122){
                guesses++;
                printf("Oops! \'%s\' is not a valid letter: ", guessed_word);
                get_guessed_word(secret, guessed_letters, guessed_word);
            }
            else {
                bool is_letter_available = false;
                for (int i = 0; i < strlen(available_letters); i++){
                    if (available_letters[i] == guessed_letter){
                        is_letter_available = true;
                    }
                }
                if (is_letter_available == false){
                    guesses++;
                    printf("Oops! You've already guessed that letter: ");
                    get_guessed_word(secret, guessed_letters, guessed_word);
                }
                else{
                    guessed_letters[count_of_normal_guesses] = guessed_letter;
                    guessed_letters[count_of_normal_guesses + 1] = '\0';
                    count_of_normal_guesses++;
                    bool is_gueessed_letter_in_secret_word = false;
                    for (int i = 0; i < strlen(secret); i++){
                        if (secret[i] == guessed_letter){
                            is_gueessed_letter_in_secret_word = true;
                        }
                    }
                    if (is_gueessed_letter_in_secret_word == true){
                        printf("Good guess: ");
                        guesses++;
                    }
                    else {
                        printf("Oops! That letter is not in my word: ");
                    }
                    get_guessed_word(secret, guessed_letters, guessed_word);
                    if (is_word_guessed(secret, guessed_word) == 1){
                        guesses = 0;
                        printf("-------------\nCongratulations, you won!\n");
                    }
                }
            }
        }
        guesses--;
    }
    if (guesses == 0){
        printf("-------------\nSorry, you ran out of guesses. The word was %s.\n", secret);
    }
}
