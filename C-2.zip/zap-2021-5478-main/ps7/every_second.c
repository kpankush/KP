#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]){
	FILE *f = fopen(argv[1], "r");
	char line_to_read[1000];
	int position_in_line = 0;
	char check_if_not_end_variable;
	while ((check_if_not_end_variable = fgetc(f)) != EOF){
		line_to_read[position_in_line] = check_if_not_end_variable;
		position_in_line++;
	}
	line_to_read[position_in_line] = '\0';
	fclose(f);
	

	
	int start_index = 0;
	for (int i = 0; i < position_in_line - 5; i++){
	    if ((line_to_read[i] == 'S')
    	    && (line_to_read[i + 1] == 'T')
    	    && (line_to_read[i + 2] == 'A')
    	    && (line_to_read[i + 3] == 'R')
    	    && (line_to_read[i + 4] == 'T')
    	    && (line_to_read[i + 5] < 65 || (line_to_read[i + 5] < 90 
    	    && line_to_read[i + 5] > 97) || line_to_read[i + 5] > 122))
	    {
	        start_index = i + 5;
	    }
	}
	
	
	
	char line_to_write[1000];
	int to_write_index = 0;
	int count_of_words = 0;
	for (int i = start_index; i < position_in_line - 4; i++){
	    if ((line_to_read[i] == 'S')
    	    && (line_to_read[i + 1] == 'T')
    	    && (line_to_read[i + 2] == 'O')
    	    && (line_to_read[i + 3] == 'P')
    	    && (line_to_read[i + 4] < 65 || (line_to_read[i + 4] < 90 
    	    && line_to_read[i + 4] > 97) || line_to_read[i + 4] > 122)){
    	        break;
    	    }
    	
	    if (line_to_read[i] == ' ' && line_to_read[i + 1] != ' '){
	        count_of_words++;
	        if (to_write_index == 0){
	            i++;
	        }
	    }
	    
	    if (count_of_words % 2 == 0 && count_of_words > 0){
	        line_to_write[to_write_index] = line_to_read[i];
	        to_write_index++;
	    }
	}
	if (line_to_write[to_write_index - 1] == ' ')
        {
            to_write_index--;
    	}
    line_to_write[to_write_index] = '\0';
    
    

	FILE *f2 = fopen(argv[2], "w");
	for (int i = 0; i < to_write_index; i++)
		fputc(line_to_write[i], f2);
	fclose(f2);
	return 0;
}
