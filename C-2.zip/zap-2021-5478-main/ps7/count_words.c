#include <stdbool.h>
#include <stdio.h>

int main(int argc, char* argv[]){
	FILE *f = fopen(argv[1], "r");
	char line_to_read[1000];
	int position_in_line = 0;
	char check_if_not_end_variable;
	while ((check_if_not_end_variable = fgetc(f)) != EOF){
		line_to_read[position_in_line] = check_if_not_end_variable;
		position_in_line++;
	}
	line_to_read[position_in_line] = '\0';
	fclose(f);
    
	
	
	int counter = 0;
	for (int i = 0; i < position_in_line; i++){
	    if (line_to_read[i] >= 65
	    && line_to_read[i] <= 90)
	    {
	        line_to_read[i] += 32;
	    }
	}
	for (int i = 0; i < position_in_line - 5; i++){
	    if ((line_to_read[i] == 'a')
    	    && (line_to_read[i + 1] == 'n')
    	    && (line_to_read[i + 2] == 'a')
    	    && (line_to_read[i + 3] == 'n')
    	    && (line_to_read[i + 4] == 'a')
    	    && (line_to_read[i + 5] == 's'))
	    {
	        counter++;
	    }
	}
	
	
	
	char line_to_write[10];
	int count_of_digits = 0;
	if (counter == 0){
	    line_to_write[0] = '0';
	    line_to_write[1] = '\0';
	    count_of_digits++;
	}
	else {
	    while (counter > 0){
    	    line_to_write[count_of_digits] = (counter % 10) + '0';
    	    counter /= 10;
    	    count_of_digits++;
    	}
    	line_to_write[count_of_digits] = '\0';
    	for (int i = 0; i < count_of_digits / 2; i++){
    	    char tmp_for_swap = line_to_write[i];
    	    line_to_write[i] = line_to_write[count_of_digits - i - 1];
    	    line_to_write[count_of_digits - i - 1] = tmp_for_swap;
    	}
	}
	
	

	FILE *f2 = fopen(argv[1], "w");
	for (int i = 0; i < count_of_digits; i++)
		fputc(line_to_write[i], f2);
	fclose(f2);
	return 0;
}
