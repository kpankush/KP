print("\n\t\t\tКто твой папа?")
print("\n1.Найти по имени""\n2.Добавить 'cын-отец'", "\n3.Изменить имя отца" "\n4.Удалить 'сын-отец'", "\n5.ВЫХОД")


names = {"Андрей": "Алексей", "Влад": "Сергей", "Аня": "Саша", "Вадим": "Кирилл"}
choice = None

while choice != "0":

    choice = input("\nВаш выбор: ")

    if choice == "1":
        name = input("Имя: ")
        if name in names:
            father = names[name]
            print("\n", name, "отец", father)

        else:
            print("Незнакомое мне имя", name)


    elif choice == "2":
        name = input("Добавьте новое имя: ")
        father = input("Впишите отца: ")
        names[name] = father
        print("Готово.")



    elif choice == "3":
        name = input("Выберите имя для которого вы хтотите изменить имя отца ")
        if name in names:
            father = input("Впишите имя отца: ")
            names[name] = father
            print("Готово.")

        else:
            print("Такого имени пока нет! Добавте его.")



    elif choice == "4":
        name = input("Какое имя вы хотите удалить? ")
        if name in names:
            del names[name]
            print("Готово.")

        else:
            print("Имени", name, "нету.")



    elif choice == "5":
        break
input("\nНажмите Enter, чтобы выйти...")
            
            
