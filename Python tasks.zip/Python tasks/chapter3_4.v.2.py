
import random

number = int(input("Выбери число от 0 до 100: "))

score = 0
tries_1 = 0

one = 2

while tries_1 != number:
    
    tries_1 = random.randint(1, 100)

    
    if random.randint == tries_1:
        continue

    
    if tries_1 < number:
        tries_1+=one

        
    if tries_1 > number:
        tries_1 - one

        
    score += 1
    
    print ("score :", score, "number :", tries_1)

    
    if tries_1 == number:
        print("Компьютер отгадал")
        break
    

input("\n\nHaжмите Enter, чтобы выйти.")
