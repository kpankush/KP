import random


def ask_number(low=0,high=5):
    guess_num = ask_number()

    
def main():
    
    low = 0
    high = 5
    guess_num = None
    guess_count=0

    print('Я загадала целое число от 0 до 100. Угадай с 5 попыток!')

    num = random.randint(1, 100)

    print('hint:', num)


    while guess_count in range(low,high):
        try:
            guess_num = int(input("Это число: "))
        except ValueError:
            print('Invalid symbol')
            continue
        
        guess_count+=1
        
        if guess_num < num: 
            print('Больше!') 
        elif guess_num > num: 
            print('Меньше!') 
        elif guess_num == num:
            print('Ничего себе! Ты отгадал! Это правда', num)
            print('Количество попыток:', guess_count)
            break

    if guess_num != num:
        print('О, ужас! Ты совершенно не умеешь читать мои мысли!\n')

#Так и не смог угадать число за 5 попыток 
main ()
input('Нажмите Entr, чтобы выйти.')
