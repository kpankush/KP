
number = int(input("Выбери число :"))

tries = 0

while tries != number:
    
    tries+=1
    print("Попытка :", tries)
    if tries == number:
        print("Компьютер отгадал")
        break
    

input("\n\nHaжмите Enter, чтобы выйти.")

