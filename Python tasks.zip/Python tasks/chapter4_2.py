print("\n\t\t\t\t Наоборот")


word = input("Напиши слово: ")
print(word[::-1])


input("\n\n Нажмите Enter, чтобы выйти.")
