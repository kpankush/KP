

import random

word = ["python", "qwerty", "return", "random","options","format","run","file","edit","window","help","users","documents"]

random.shuffle(word)

print (word)
