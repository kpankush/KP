
import random

print("\t\t\t\tОрёл и Решка")

head = 0
tail = 0

throw = 0


while throw != 100:
    
    throw += 1
    result = random.randint(1, 2)
    
    print("Броски: ", (101-throw))
    
    if result == 1:
        head += 1
        
    else:
        tail += 1

        
print ("Орёл :", head, "Решка :", tail)
input("\nНажмите Enter, чтобы выйти.")
    
