print("\n\t\t\tКто твой папа?")
print("\n1.Найти по имени""\n2.Добавить 'cын-отец-дед'", "\n3.Изменить имя отца","\n4.Изменить имя деда" "\n5.Удалить 'сын-отец-дед'", "\n6.ВЫХОД")


names = {"Андрей":{ "Алексей": "Генадий"}, "Влад": {"Сергей": "Степан"}, "Аня": {"Саша": "Валентин"}, "Вадим": {"Кирилл": "Николай"}}
choice = None


while choice != "0":

    choice = input("\nВаш выбор: ")

    if choice == "1":
        name = str(input("Имя: "))
        
        if name in names:
            father = list(names[name].keys())
            g_father = names[name][father[0]]
            print("\n", name, "отец", father[0], "дед", g_father)

        else:
            print("Незнакомое мне имя", name)



    elif choice == "2":
        name = str(input("Добавьте новое имя: "))
        father = str(input("Напишите имя отца: "))
        g_father = str(input("Напишите имя деда: "))
        names[name] = {father: g_father}
        print("Готово.")



    elif choice == "3":
        name = str(input("Выберите имя для которого вы хтотите изменить имя отца? "))

        if name in names:
            father = list(names[name].keys())
            g_father = names[name][father[0]]
            father = str(input("Впишите новое имя отца: "))
            names[name] = {father: g_father}
            print("Готово.")

        else:
            print("Такого имени пока нет! Добавте его.")




    elif choice == "4":
        name = input("Выберите имя для которого вы хтотите изменить имя деда? ")
        father = input("Напишите правильное имя отца: ")

        if father in list(names[name].keys()) and name in names:
            g_father = input("Впишите новое имя деда: ")
            names[name] = {father: g_father}
            print("Гтово.")
        else:
            
            print("Имени 1 или 2 нет! ")





    elif choice == "5":
        name = str(input("Какое имя вы хотите удалить? "))

        if name in names:
            del names[name]
            print("Готово.")

        else:
            print("Имени", name, "нету.")





    elif choice == "6":
        break
input("\nНажмите Enter, чтобы выйти...")
            
            
