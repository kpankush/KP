strength = 0
health = 0
wisdom = 0
agility = 0

first = None
second = None


while second != 0:

    print('Таблица:')
    print("\nСила:", strength, "\nЗдоровье:", health, "\nМудрость:", wisdom, "\nЛовкость:", agility)

    points = (30 - strength - health - wisdom - agility)

   
    print("\n\n Ваш выбор:")
    print("\n 1.Добавить очки.""\n 2.Убрать очки.""\n 3.Закончить\n")

    second = int(input())
    if second == 1:
        
        print("Выберите характеристику")
        print("\n 1.Сила""\n 2.Здоровье""\n 3.Мудрость""\n 4.Ловкость\n" )
        first = int(input())

        if first == 1:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and scores <= points:                
                strength+=scores
            else:
                print("Недопустимое количество")

        elif first == 2:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and scores <= points:
                health+=scores
            else:
                print("Недопустимое количество")

        elif first == 3:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and scores <= points:
                wisdom+=scores
            else:
                print("Недопустимое количество")

        if first == 4:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and scores <= points:
                agility+=scores
            else:
                print("Недопустимое количество")






                

    elif second == 2:

        print("Выберите характеристику")
        print("\n 1.Сила""\n 2.Здоровье""\n 3.Мудрость""\n 4.Ловкость\n" )
        first = int(input())

        if first == 1:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and (strength -scores) >= 0:                
                strength-=scores
            else:
                print("Недопустимое количество")

        elif first == 2:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and (health -scores) >= 0:
                health-=scores
            else:
                print("Недопустимое количество")

        elif first == 3:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and (wisdom -scores) >= 0:
                wisdom-=scores
            else:
                print("Недопустимое количество")

        if first == 4:
            print("Добавить очки:\n")
            scores = int(input())
            if scores >= 0 and (agility -scores) >= 0:
                agility-=scores
            else:
                print("Недопустимое количество")







    elif second == 3:
        if points == 0:
            print("Готово!")
            print("\nСила:", strength, "\nЗдоровье:", health, "\nМудрость:", wisdom, "\nЛовкость:", agility)
            input("\nНажмите Enter, чтобы выйти...")
            break
        else:
            print("Error. Используйте все очки.\n")


