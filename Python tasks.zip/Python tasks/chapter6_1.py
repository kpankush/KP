#def ask_number(question, low, high, step = 1):
   # """Просит ввести число из диапазона."""
    #response = None
    #while response not in range(low, high, step):
        #response = int(input(question))
    #return response


import random

print("\tДобро пожаловать в игру 'Отгадай число'! " )
print("\nЯ загадал натуральное число из диапазона от 1 до 100.")
print("Постарайтесь отгадать его за минимальное число попыток. \n")

the_number = random.randint(1, 100)
quess = None

def ask_number(low = 0,high = 9):
    tries = 0
    
    while tries in range(low, high):
        #try:
            
        guess = int(input("Ваше предположение: "))
        tries += 1

        
        if (guess < 0 or guess > 100):           
            print("Допустимые числа от 0 до 100")
            continue
        
        elif guess > the_number:
            print("Меньше...")
        
        elif guess < the_number:
            print("Больше...")
        
            #elif tries > 9 and guess!=the_number: 
                #print ("Вы лузер")
                #break
   
        elif guess == the_number: 
            print("Вам удалось отгадать число! Это в самом деле", the_number)
            print("Вы затратили на отгадывание всего лишь", tries, "попыток!\n")
            
        #except ValueError:
         #   print('Недопустимый символ')

    return guess
    
ask_number()
if guess != the_number:
    print ("Вы лузер")


input("\n\nHaжмите Enter, чтобы выйти.")




