
import random

print("\n\t\t\t\tСюрприз!")

surprise = random.randint(1, 2)


if surprise == 1:
    print( 
    """
    ____/\____  
    \________/ 
      | * *|
      |__^_|
       _||_
        ||
        /\
       
      
     """)
    
    
elif surprise == 2:
     print( 
         """
 
    qwertyui
    """)
