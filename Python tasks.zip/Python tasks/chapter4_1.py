print("\n\t\t\t\tСчиталка")

print("\n\n\nПеречислим кратные пяти:")
print("\nК примеру: first(0), second(50), third(5)\n\n for i in range(0, 50, 5)\n\t print(i, end=" ")")
print("\n Результат: 0, 5, 10, 15, 20, 25, 30, 35, 40, 45")


first = int(input("\n\n first: "))
second = int(input("second: "))
third = int(input("third: "))


for i in range (first, second, third):
    print(i, end = " ")

input("\n\n Нажмите Enter, чтобы выйти.")
